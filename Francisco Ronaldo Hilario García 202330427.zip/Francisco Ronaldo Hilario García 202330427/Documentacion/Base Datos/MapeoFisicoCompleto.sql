create table cine(
	codigo varchar(25) not null,
    nombre varchar(100) not null,
    ubicacion varchar(150) not null,
    fecha_creacion Date not null,
    creditos_cartera decimal(10,2) default 0,
    activo boolean default true,
    constraint pk_cine primary key (codigo)
);

create table usuario(
	id varchar(25) not null,
    nombre varchar(100) not null,
    correo varchar(100) not null,
    contraseña varchar(50) not null,
    telefono varchar(25) not null,
    creditos decimal(10,2) default 0,
    activo boolean default true,
    
    constraint pk_usuario primary key (id)
);

create table admin_sistema(
	id_usuario varchar(25) not null,
    constraint pk_admin_sistema primary key (id_usuario),
    constraint fk_usuario_admin_sistema foreign key (id_usuario)
    references usuario(id) on delete cascade
);

CREATE TABLE admin_cine (
    id_usuario VARCHAR(25) NOT NULL,
    codigo_cine VARCHAR(25) NOT NULL,

    CONSTRAINT pk_admin_cine PRIMARY KEY (id_usuario),

    CONSTRAINT fk_usuario_admin_cine FOREIGN KEY (id_usuario)
        REFERENCES usuario (id)
        ON DELETE CASCADE,

    CONSTRAINT fk_cine_admin_cine FOREIGN KEY (codigo_cine)
        REFERENCES cine (codigo)
        ON DELETE CASCADE
);


create table anunciante(
	id_usuario varchar(25) not null,
    activo boolean default true,
    constraint pk_anunciante primary key (id_usuario),
    constraint fk_usuario_anunciante foreign key(id_usuario)
    references usuario (id)
);

create table precio_anuncio (
	id int auto_increment primary key,
    tipo varchar(25) not null,
    precio_venta_dia decimal(10,2),
    precio_bloqueo_dia decimal(10,2)
);

-- se necesita crear uno al iniciar el programa
create table costo_bloqueo_anuncio(
    id int auto_increment primary key,
    costo decimal(10,2) not null
);

create table costo_funcionamiento (
	id int auto_increment primary key,
    codigo_cine varchar(25) not null,
    fecha_registro date not null,
    costo_dia decimal(10,2) not null,

    constraint fk_costo_funcionamiento foreign key (codigo_cine)
    references cine(codigo) on delete cascade
);

create table costo_global(
    id int auto_increment primary key,
    costo decimal(10,2) not null
);

create table categoria_pelicula (
	id int auto_increment primary key,
    nombre varchar(50) not null
);

create table pelicula(
	codigo varchar(25) not null,
    titulo varchar (100) not null,
    sinopsis varchar (300) not null,
    duracion int not null,
    director varchar (100) not null,
    cast varchar(200) not null,
    poster mediumblob not null,
    clasificacion varchar(25) not null,
    fecha_estreno date not null,
    activa boolean default true,
    constraint pk_pelicula primary key (codigo)
);


create table poster (
	id int auto_increment primary key,
    codigo_pelicula varchar(25) not null,
    imagen mediumblob not null,
    constraint fk_pelicula_poster foreign key (codigo_pelicula)
    references pelicula(codigo)
);


create table registro_categoria_pelicula(
	id_categoria int not null,
    codigo_pelicula varchar(25) not null,
    constraint pk_registro_categoria_pelicula primary key (id_categoria, codigo_pelicula),
    constraint fk_categoria_registro_categoria foreign key(id_categoria) 
    references categoria_pelicula(id),
    constraint fk_pelicula_registro_categoria foreign key(codigo_pelicula) 
    references pelicula(codigo) on delete cascade
);

create table anuncio(
	codigo varchar(25) not null,
    id_anunciante varchar(25) not null,
    titulo varchar (50) not null,
    tipo varchar (20) not null,
    descripcion varchar (300) not null,
    imagen mediumblob,
    link_video varchar(300),
    fecha_registro date not null,
    precio decimal(10,2) not null,
    duracion_dias int not null,
    dias_activo int default 0,
    activo boolean default true,
    
    constraint pk_anuncio primary key (codigo),
    constraint fk_anunciante_anuncio foreign key(id_anunciante)
    references anunciante(id_usuario) on delete cascade
);

create table sala(
    codigo varchar(25) not null,
    codigo_cine varchar(25) not null,
    nombre varchar(100) not null,
    filas int not null,
    columnas int not null,
    habilitado_com_y_cal boolean default true,
    activo boolean default true,
    constraint pk_sala primary key (codigo),
    constraint fk_sala foreign key (codigo_cine)
    references cine(codigo) on delete cascade
);

create table proyeccion(
	codigo varchar(25) not null,
    codigo_pelicula varchar(25) not null,
    codigo_sala varchar(25) not null,
    fecha date not null,
    hora_inicio time not null,
    hora_fin time not null,
    precio decimal(10,2) not null,
    disponible boolean default true,
    
    constraint pk_proyeccion primary key(codigo),
    
    constraint fk_pelicula_proyeccion foreign key(codigo_pelicula)
    references pelicula(codigo) on delete cascade,
    
    constraint fk_sala_proyeccion foreign key (codigo_sala)
    references sala(codigo) on delete cascade
);

create table pago_bloqueo_anuncio(
	id int auto_increment primary key,
    codigo_cine varchar (25) not null,
    fecha_pago date not null,
    total_dias int not null,
    dias_activo int default 0,
    costo decimal(10,2) not null,
    activo boolean default true,
    
    constraint fk_cine_pago_bloqueo_anuncio foreign key (codigo_cine)
    references cine(codigo) on delete cascade
);

create table opinion_sala(
	id int auto_increment primary key,
    codigo_sala varchar(25) not null,
    id_usuario varchar(25) not null,
    comentario varchar(300) not null,
    calificacion int not null,
    fecha date not null,
    
    constraint fk_sala_opinion_sala foreign key (codigo_sala)
    references sala(codigo) on delete cascade,
    
    constraint fk_usuario_opinion_sala foreign key (id_usuario)
    references usuario(id) on delete cascade
    
);


create table opinion_pelicula(
	id int auto_increment primary key,
    codigo_pelicula varchar(25) not null,
    id_usuario varchar(25) not null,
    comentario varchar(300) not null,
    calificacion int not null,
    fecha date not null,
    
    constraint fk_pelicula_opinion_pelicula foreign key (codigo_pelicula)
    references pelicula(codigo) on delete cascade,
    
    constraint fk_usuario_opinion_pelicula foreign key (id_usuario)
    references usuario(id) on delete cascade
    
);
