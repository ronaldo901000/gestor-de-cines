insert into usuario (
    id,
    nombre,
    correo,
    contraseña,
    telefono,
    creditos,
    activo
) values (
    'admin',
    'administrador general',
    'admin@gmail.com',
    'MTIzNDU=',
    '5555-5555',
    0,
    true
);

insert into admin_sistema (id_usuario)
values ('admin');


-- inicializacion de los precios de anuncios
create table precio_anuncio (
	id int auto_increment primary key,
    tipo varchar(25) not null,
    precio_venta_dia decimal(10,2),
    precio_bloqueo_dia decimal(10,2)
);

insert into precio_anuncio (tipo, precio_venta_dia, precio_bloqueo_dia)
values
('TEXTO', 50.00, 25.00),
('TEXTO E IMAGEN', 75.00, 50.00),
('TEXTO Y VIDEO', 100.00, 75.00);


-- inicializacion del costo global
insert into costo_global (costo) values(100.00);

insert into costo_bloqueo_anuncio(costo) values (100);
